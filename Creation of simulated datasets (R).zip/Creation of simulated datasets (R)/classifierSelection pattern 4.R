NonLinear = function(n,a){
  x = rnorm(n+0.1*n, 5, 1)
  x <- x[x >= 3]
  x <-sample(x, n)
  y = (x-3)^a/10 + rnorm(n,0,1)
  y[is.na(y)]<-min(y,na.rm=TRUE)
  data.frame(x,y)
}
NonLinear2 = function(n,a) {
  x = rnorm(n+0.1*n, 5, 1)
  x <- x[x >= 3]
  x <-sample(x, n)
  y = (x-3)^a/10 + 
    sample(c(-1,1), 10, replace=TRUE) * runif(n,3,5)
  y[is.na(y)]<-min(y,na.rm=TRUE)
  data.frame(x,y)
}
NonLinear3 = function(n,a) {
  x = rnorm(n+0.1*n, 5, 1)
  x <- x[x >= 3]
  x <-sample(x, n)
  y = (x-3)^a/10 + 
    sample(1, 10, replace=TRUE) * runif(n,1.6,4.5)
  y[is.na(y)]<-min(y,na.rm=TRUE)
  data.frame(x,y)
}

library(fdm2id)
library(varbvs)
library(caret)
library(plotly)
m=100; 
ndata=20;
resultVAUC <- matrix(0,6,ndata)
ListX<-list();ListY<-list(); ListID<-list(); ListCoef<-list();
for(i in 1:ndata){
  a<-runif(1,3,4)
  NL = NonLinear(m,a)
  plot(NL, ylim=c(-4,10))
  NLO = NonLinear2(m,a)
  points(NLO, pch=20, col="red")
  Yaux<- rep("b",2*m)
  Yaux[1:m]<-"a"
  ListY[[i]]<-t(Yaux)
  ListX[[i]]<-rbind(NL,NLO)
  ListID[[i]]<-t(i*rep(1,2*m))
  data_set<-data.frame(rbind(NL,NLO),Yaux) 
  ctrl<-trainControl(method="CV",number=4, summaryFunction=twoClassSummary, classProbs = TRUE)
  logreg_fit<-train(Yaux ~ ., data = data_set, method="glm", family="binomial", trControl = ctrl, metric="ROC")
  resultVAUC[1,i] <- logreg_fit$results$ROC[1]
  tree_fit<-train(Yaux ~ ., data = data_set, method = "rpart", trControl = ctrl, metric="ROC")
  resultVAUC[2,i] <- tree_fit$results$ROC[1]
  knn_fit<-train(Yaux ~ ., data = data_set, method = "knn",tuneLength = 3, trControl = ctrl, metric="ROC")
  resultVAUC[3,i] <- knn_fit$results$ROC[1]
  rf_fit<-train(Yaux ~ ., data = data_set, method = "rf", trControl = ctrl, metric="ROC")
  resultVAUC[4,i] <- rf_fit$results$ROC[1]
  nnet_fit<-train(Yaux ~ ., data = data_set, method = "nnet", trControl = ctrl, metric="ROC")
  resultVAUC[5,i] <- nnet_fit$results$ROC[1]
  svm_fit<-train(Yaux ~ ., data = data_set, method = "svmRadial", trControl = ctrl, tuneLength = 5, metric="ROC")
  resultVAUC[6,i] <- svm_fit$results$ROC[1]
}
Meanvector<-colMeans(t(resultVAUC))
Meanvector

X=do.call(rbind,ListX) 
Y=t(do.call(cbind,ListY)) 
TSID=t(do.call(cbind,ListID)) 
data_set2<-data.frame(X,Y,TSID) 
attach(data_set2)
p <- data_set2 %>%
  plot_ly(
    x = X1, 
    y = X2, 
    color = ~Y, 
    frame = ~TSID, 
    type = 'scatter',
    mode = 'markers'
  ) 
p