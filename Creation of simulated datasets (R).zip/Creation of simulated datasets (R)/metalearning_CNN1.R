#This code creates simulated datasets with homogeneous sizes (CNN1) with N=1000 and and M=20000;
#Warning!"DataML.csv" is a very large file (4.4 GB). A sample is provided "DataML1.csv" is provided.


NonLinear = function(n,a){
  X1 = rnorm(n+0.1*n, 5, 1)
  X1 <- X1[X1 >= 3]
  X1 <-sample(X1, n)
  X2 = (X1-3)^a/10 + rnorm(n,0,1)
  X2[is.na(X2)]<-min(X2,na.rm=TRUE)
  data.frame(X1,X2)
}
NonLinear2 = function(n,a) {
  X1 = rnorm(n+0.1*n, 5, 1)
  X1 <- X1[X1 >= 3]
  X1 <-sample(X1, n)
  X2 = (X1-3)^a/10 + 
    sample(c(-1,1), 10, replace=TRUE) * runif(n,3,5)
  X2[is.na(X2)]<-min(X2,na.rm=TRUE)
  data.frame(X1,X2)
}
NonLinear3 = function(n,a) {
  X1 = rnorm(n+0.1*n, 5, 1)
  X1 <- X1[X1 >= 3]
  X1 <-sample(X1, n)
  X2 = (X1-3)^a/10 + 
    sample(1, 10, replace=TRUE) * runif(n,1.6,4.5)
  X2[is.na(X2)]<-min(X2,na.rm=TRUE)
  data.frame(X1,X2)
}

library(varbvs)
library(caret)
library(fdm2id)
library(questionr)
m=500; #each tabular dataset has 2*m samples
ndata=20000;#it generate 5*ndata datasets
d1=0.04; d2=0.04; s=0.025; 
ListX<-list();ListY<-list(); ListID<-list(); ListLabel<-list();
for(i in 1:ndata){
  x1<-cbind(randn(m,1)*s-d1*runif(1),randn(m,1)*s-d2*runif(1))
  x2<-cbind(randn(m,1)*s+d1*runif(1),randn(m,1)*s+d2*runif(1))
  Xaux<-data.frame(rbind(x1,x2))
  preProcValues<- preProcess(Xaux, method = c("center","scale"))
  ListX[[i]]<-predict(preProcValues, Xaux)
  Yaux<- rep(0,2*m)
  Yaux[1:m]<-1
  ListY[[i]]<-t(Yaux)
  ListID[[i]]<-t(i*rep(1,2*m))
  ListLabel[[i]]<-t(1*rep(1,2*m))
}

for(i in (ndata+1):(2*ndata)){
  x1<-cbind(randn(m/2,1)*s-d1*runif(1),randn(m/2,1)*s-d2*runif(1))
  x2<-cbind(randn(m/2,1)*s+d1*runif(1),randn(m/2,1)*s+d2*runif(1)+0.1)
  x3<-cbind(randn(m/2,1)*s+d1*runif(1),randn(m/2,1)*s+d2*runif(1))
  x4<-cbind(randn(m/2,1)*s-d1*runif(1),randn(m/2,1)*s-d2*runif(1)+0.1)
  Xaux<-data.frame(rbind(x1,x2,x3,x4))
  preProcValues<- preProcess(Xaux, method = c("center","scale"))
  ListX[[i]]<-predict(preProcValues, Xaux)
  Yaux<- rep(0,2*m)
  Yaux[1:m]<-1
  ListY[[i]]<-t(Yaux)
  ListID[[i]]<-t(i*rep(1,2*m))
  ListLabel[[i]]<-t(2*rep(1,2*m))
}
for(i in (2*ndata+1):(3*ndata)){
  Xaux<-data.twomoons(runif(1,0.7,1.3),m,runif(1,0.2,0.35))
  Xaux <- rename.variable(Xaux, "X", "X1")
  Xaux <- rename.variable(Xaux, "Y", "X2")
  Xaux<-subset(Xaux, select = -c(Class))
  preProcValues<- preProcess(Xaux, method = c("center","scale"))
  ListX[[i]]<-predict(preProcValues, Xaux)
  Yaux<- rep(0,2*m)
  Yaux[1:m]<-1
  ListY[[i]]<-t(Yaux)
  ListID[[i]]<-t(i*rep(1,2*m))
  ListLabel[[i]]<-t(3*rep(1,2*m))
}
for(i in (3*ndata+1):(4*ndata)){
  a<-runif(1,3,4)
  NL = NonLinear(m,a)
  NLO = NonLinear2(m,a)
  Xaux<-rbind(NL,NLO)
  preProcValues<- preProcess(Xaux, method = c("center","scale"))
  ListX[[i]]<-predict(preProcValues, Xaux)
  Yaux<- rep(0,2*m)
  Yaux[1:m]<-1
  ListY[[i]]<-t(Yaux)
  ListID[[i]]<-t(i*rep(1,2*m))
  ListLabel[[i]]<-t(4*rep(1,2*m))
}
for(i in (4*ndata+1):(5*ndata)){
  a<-runif(1,3,4)
  NL = NonLinear(m,a)
  NLO = NonLinear3(m,a)
  Xaux<-rbind(NL,NLO)
  preProcValues<- preProcess(Xaux, method = c("center","scale"))
  ListX[[i]]<-predict(preProcValues, Xaux)
  Yaux<- rep(0,2*m)
  Yaux[1:m]<-1
  ListY[[i]]<-t(Yaux)
  ListID[[i]]<-t(i*rep(1,2*m))
  ListLabel[[i]]<-t(5*rep(1,2*m))
}
X=do.call(rbind,ListX) 
Y=t(do.call(cbind,ListY)) 
VID=t(do.call(cbind,ListID)) 
VLabel=t(do.call(cbind,ListLabel)) 
res<-cbind(VID,X,Y,VLabel)
write.csv(res, file = "DataML.csv",row.names=FALSE)