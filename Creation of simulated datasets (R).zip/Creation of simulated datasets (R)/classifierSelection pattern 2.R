library(varbvs)
library(caret)
library(plotly)
m=100; 
ndata=3;
resultVAUC <- matrix(0,6,ndata)
d1=0.08; d2=0.08; s=0.015; 
ListX<-list();ListY<-list(); ListID<-list(); ListCoef<-list();
for(i in 1:ndata){
  x1<-cbind(randn(m,1)*s-d1*runif(1),randn(m,1)*s-d2*runif(1))
  x2<-cbind(randn(m,1)*s+d1*runif(1),randn(m,1)*s+d2*runif(1))
  x3<-cbind(randn(m,1)*s+d1*runif(1),randn(m,1)*s-d2*runif(1))
  x4<-cbind(randn(m,1)*s-d1*runif(1),randn(m,1)*s+d2*runif(1)) 
  ListX[[i]]<-rbind(x1,x2,x3,x4)
  Yaux<- rep("b",4*m)
  Yaux[1:(2*m)]<-"a"
  ListY[[i]]<-t(Yaux)
  ListID[[i]]<-t(i*rep(1,4*m))
  data_set<-data.frame(rbind(x1,x2,x3,x4),Yaux) 
  ctrl<-trainControl(method="CV",number=4, summaryFunction=twoClassSummary, classProbs = TRUE)
  logreg_fit<-train(Yaux ~ ., data = data_set, method="glm", family="binomial", trControl = ctrl, metric="ROC")
  resultVAUC[1,i] <- logreg_fit$results$ROC[1]
  tree_fit<-train(Yaux ~ ., data = data_set, method = "rpart", trControl = ctrl, metric="ROC")
  resultVAUC[2,i] <- tree_fit$results$ROC[1]
  knn_fit<-train(Yaux ~ ., data = data_set, method = "knn",tuneLength = 3, trControl = ctrl, metric="ROC")
  resultVAUC[3,i] <- knn_fit$results$ROC[1]
  rf_fit<-train(Yaux ~ ., data = data_set, method = "rf", trControl = ctrl, metric="ROC")
  resultVAUC[4,i] <- rf_fit$results$ROC[1]
  #nnet_fit<-train(Yaux ~ ., data = data_set, method = "nnet", trControl = ctrl, metric="ROC")
  #resultVAUC[5,i] <- nnet_fit$results$ROC[1]
  svm_fit<-train(Yaux ~ ., data = data_set, method = "svmRadial", trControl = ctrl, tuneLength = 5, metric="ROC")
  resultVAUC[6,i] <- svm_fit$results$ROC[1]
  #lda_fit<-train(Yaux ~ ., data = data_set, method="lda", trControl = ctrl, metric="ROC")
  #resultVAUC[7,i] <- lda_fit$results$ROC[1]  
}
Meanvector<-colMeans(t(resultVAUC))
Meanvector

X=do.call(rbind,ListX) 
Y=t(do.call(cbind,ListY)) 
TSID=t(do.call(cbind,ListID)) 
data_set2<-data.frame(X,Y,TSID) 
attach(data_set2)
p <- data_set2 %>%
  plot_ly(
    x = X1, 
    y = X2, 
    color = ~Y, 
    frame = ~TSID, 
    type = 'scatter',
    mode = 'markers'
  ) 
p